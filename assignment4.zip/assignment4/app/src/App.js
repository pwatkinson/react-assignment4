import React, { useState, useEffect } from "react";
import axios from "axios";
import { Switch, Route } from "react-router-dom";
import styles from "./App.module.css";

// Import Components
import Header from "./components/Header/Header";
import Loading from "./components/Loading/Loading";

// Import Pages
import History from "./pages/History/History";
import About from "./pages/About/About";
import Rockets from "./pages/Rockets/Rockets";
import Rocket from "./pages/Rocket/Rocket";

function App() {
  const [loading, setLoading] = useState(true);
  const [spaceArray, setSpaceArray] = useState([]);
  
  // variable for About page
  const [info, setInfo] = useState(null);
  // callback functions to set info array within About component
  const setInfo2 = array => {
    setInfo(array);
  };
  const getInfo2 = () => {
    return info;
  };

  // variable for Rockets page
  const [rocketsInfo, setRocketsInfo] = useState([]);
  // callback functions to set rocketsInfo array within Rockets page
  const setRocketsArray = array => {
    setRocketsInfo(array);
  };
  const getRocketsArray = () => {
    return rocketsInfo;
  };

  // useEffect runs after the component renders
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      clearTimeout(loadingTimer);
      // Every time we change the state, we cause the component
      // to re-render

      // Once 2000ms is up, we make the call, any additional time that it takes
      // for the data to return to us will add up
      axios.get("https://api.spacexdata.com/v3/history").then(response => {
        console.log(response.data);
        setSpaceArray(response.data);
        setLoading(false);
      });
    }, 2000);
  }, []);

  return (
    <div className={styles.app}>
      <div className={styles.header}>
        <Header />
      </div>
      <div className={styles.content}>
        {loading ? (
          <Loading />
        ) : (
          <Switch>
            <Route
              exact
              path="/"
              render={() => {
                return <History historyItems={spaceArray} />;
              }}
            />

            <Route
              exact
              path="/about"
              render={() => {
                return <About getInfo3={getInfo2} setInfo3={setInfo2} />;
              }}
            />

            <Route
              exact
              path="/rockets"
              render={() => {
                return (
                  <Rockets
                    setRocketsArray2={setRocketsArray}
                    getRocketsArray2={getRocketsArray}
                  />
                );
              }}
            />
            <Route
              path="/rocket/:Id"
              render={props => {
                return <Rocket rocketArray={rocketsInfo} {...props} />;
              }}
            />
          </Switch>
        )}
      </div>
    </div>
  );
}

export default App;
