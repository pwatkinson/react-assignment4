import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

import styles from "./Rockets.module.css";

import Loading from "../../components/Loading/Loading";
import Card from "../../components/Card/Card";

const Rockets = props => {
  const { setRocketsArray2, getRocketsArray2 } = props;
  const [loadingRocketInfo, setLoadingRocketInfo] = useState(true);
  let rocketsArray = [];
  let arraySize = 0;

  rocketsArray = getRocketsArray2();
  if (rocketsArray != null) arraySize = rocketsArray.length;
  console.log("Rockets component");
  console.log(rocketsArray);
  console.log("size=" + arraySize);
  if (arraySize > 0) {
    if (loadingRocketInfo === true) {
      setLoadingRocketInfo(false);
    }
  }

  // useEffect runs after the component renders
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      if (loadingRocketInfo === false) {
        return;
      }
      clearTimeout(loadingTimer);
      // Every time we change the state, we cause the component
      // to re-render

      // Once 2000ms is up, we make the call, any additional time that it takes
      // for the data to return to us will add up
      axios.get("https://api.spacexdata.com/v3/rockets").then(response => {
        console.log(response.data);
        setRocketsArray2(response.data);
        setLoadingRocketInfo(false);
      });
    }, 2000);
  }, [loadingRocketInfo, setRocketsArray2]);

  return (
    <div className={styles.rockets}>
      {loadingRocketInfo ? (
        <Loading />
      ) : (
        <React.Fragment>
          {rocketsArray.map((rocket, index) => {
            return (
              <div key={"myKey" + index}>
                <Link to={`/rocket/${index}`} className={styles.link}>
                  <Card className={styles.card}>
                    <h2>{rocket.rocket_name}</h2>
                    <p>Cost: {rocket.cost_per_launch}</p>
                    <p>Sucess Rate (%): {rocket.success_rate_pct}</p>
                  </Card>
                </Link>
              </div>
            );
          })}
        </React.Fragment>
      )}
    </div>
  );
};

export default Rockets;
