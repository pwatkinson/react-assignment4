import React, { useState, useEffect } from "react";
import axios from "axios";

import styles from "./About.module.css";

import Loading from "../../components/Loading/Loading";
import Card from "../../components/Card/Card";

const About = props => {
  const [loadingAboutInfo, setLoadingAboutInfo] = useState(true);
  //
  const { getInfo3, setInfo3 } = props;
  console.log("About component");
  console.log("About: info=" + getInfo3());
  let str = JSON.stringify(getInfo3());
  console.log(str);
  let infoArray = [];

  infoArray = getInfo3();
  console.log("infoArray=" + infoArray);
  if (infoArray !== null) {
    if (loadingAboutInfo === true) {
      setLoadingAboutInfo(false);
    }
  }

  // useEffect runs after the component renders
  useEffect(() => {
    const loadingTimer = setTimeout(() => {
      if (loadingAboutInfo === false) {
        return;
      }
      clearTimeout(loadingTimer);
      // Every time we change the state, we cause the component
      // to re-render

      // Once 2000ms is up, we make the call, any additional time that it takes
      // for the data to return to us will add up
      axios.get("https://api.spacexdata.com/v3/info").then(response => {
        console.log(response.data);
        setInfo3(response.data);
        setLoadingAboutInfo(false);
      });
    }, 2000);
  }, [loadingAboutInfo, setInfo3]);

  return (
    <div className={styles.about}>
      {loadingAboutInfo ? (
        <Loading />
      ) : (
        <Card>
          <h2>{getInfo3().name}</h2>
          <p>Founded: {getInfo3().founded}</p>
          <p>CEO: {getInfo3().ceo}</p>
          <p>COO: {getInfo3().coo}</p>
          <p>Valuation: {getInfo3().valuation}</p>
          <p>{getInfo3().summary}</p>
        </Card>
      )}
    </div>
  );
};

export default About;
