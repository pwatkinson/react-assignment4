import React from 'react';
import PropTypes from 'prop-types';
import styles from './History.module.css';
import Card from '../../components/Card/Card';

const History = (props) => {
    //console.log("Home component");
    //console.log(props);
    const { historyItems } = props;
 	
    return (
        <div className={styles.history}>
            {historyItems.map((historyItem, index) => {
                return (
                    <div key={'myKey' + index}>
                        <Card className={styles.card}>
                            <h2>{historyItem.title}</h2>
                            <p>Date: {historyItem.event_date_utc}</p>
                            <p>{historyItem.details}</p>
                            <a href={historyItem.links.wikipedia} target="_blank" >wiki article</a>
                        </Card>
                    </div>
                )
            })}
        </div>
    );
	
}

History.propTypes = {
    characters: PropTypes.array
};

export default History;
