import React from "react";
import { Link } from "react-router-dom";
import PropTypes from 'prop-types';
import styles from "./Rocket.module.css";

import Card from "../../components/Card/Card";

const Rocket = props => {
  const {rocketArray} = props;
  console.log("Rocket component");
  console.log(props);
  const { Id } = props.match.params;
  console.log("Id=" + Id);
  console.log("rocketArray=" + rocketArray);

  let name = "undefined";
  let description = "undefined";
  let company = "undefined";
  let myObj = rocketArray[Id];
  console.log("myObj=" + myObj)
  if (typeof myObj !== "undefined") {
    name = myObj.rocket_name;
    description = myObj.description;
    company = myObj.company;
  }


  return (
    <div className={styles.rocket}>
        <Card>

    			<h2>{name}</h2>
		    	<p>Description: {description}</p>
			    <p>Company: {company}</p>

           <Link to="/rockets">Exit</Link>          
        </Card>
    </div>
  );

};

Rocket.propTypes = {
  characters: PropTypes.array,
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.element,
    PropTypes.node,
])
};

export default Rocket;
